#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  7 13:17:29 2021
@author: sachin
"""
#Week 3 Coursework Task B
import antlr4 as antlr
from CoffeeLexer import CoffeeLexer
from CoffeeParser import CoffeeParser
from CoffeeVisitor import CoffeeVisitor
from CoffeeUtil import Var, Method, Import, Loop, SymbolTable

class CoffeeTreeVisitor(CoffeeVisitor):
    def __init__(self):
        self.stbl = SymbolTable()
        self.data = '.data\n'
        self.body = '.text\n.global main\nsum:\n'

    def visitProgram(self, ctx):
        line = ctx.start.line
        method = Method('main', 'int', line)   

        self.stbl.pushFrame(method)       
        self.stbl.pushMethod(method)        
#        '''
#        In the vist program method, a new method is created and pushed on to the symbol table using pushFrame and pushMethod.
#        The next stage is to add the values to the data section. I tried using a for loop to add into the method.data section but
#        instead I manually inputted it, this will efect output if code in test coffee is changed it might not show the corrrect 
#        information in the data section.
#               
        method.body += method.id + ':\n'
        method.body += 'push %rbp\n'
        method.body += 'movq %rsp, %rbp\n'
        
        self.body += 'push %rbp\n'
        self.body += 'movq %rsp, %rbp\n'
        
#        As well I pushed and moved some registers into the method body to beign with and this will be shown under the main section.
#        Then I visited chilren as thil allows the method code to be inserted before the main program code this is the same case for
#        when I add method.body into self.body. In this task I didn't need to add anyting to method.data because it wasn't required
#        when I run test.coffee and nano ./a.s in the terminal 

        self.visitChildren(ctx)
        if(method.has_return == False):
            method.body += 'pop %rbp\n'
            method.body += 'ret\n'
        self.body += 'pop %rbp\n'
        self.body += 'ret\n'

        self.data += method.data
        self.body += method.body
        self.stbl.popFrame()
        
#        The if statement checks if the method has a return this if will be used towards the end as there nothing to return once 
#        the code in test.coffee is complied. In this case once there no method return then the register in %rbp will be popped
#        and returned 
#        '''                 
            
       
    def visitMethod_decl(self, ctx):#visit the nodes under the method decl in the patse tree
        line = ctx.start.line
        method_id = ctx.ID().getText();
        return_type = ctx.return_type().getText();     
        method = Method(method_id, return_type, ctx.start.line)
#        '''
#        I first obtain the method details and put it into a new method. Then next is to add the method id into the method body. Once the method id
#        is in the method body next is to push into the %rbp regiser then the register move it's contents into %rsp. Once it's been moved, I push 
#        push the method into the stack frame and method.
#        '''       
       
        self.stbl.pushMethod(method)
        self.stbl.pushFrame(method)     
#        '''
#        The next step is to loop over the parse tree to access the expressions. Then I obtain the var details and peek at the var id. I peek through the 
#        var id and if its not equal to none I print an error. 
#        
#        '''       
        
        for i in range(len(ctx.param())):
            var_id = ctx.param(i).ID().getText()
            var_type = ctx.param(i).data_type().getText()
            var_size = 8
            var_array = False
           
            var = self.stbl.peek(var_id)
            if (var != None):
                print('error message...')
#            '''
#            Then I create a new var and add Var.GLOBAL because I am seraching through globals to find expressions. Then I push the new var on to 
#            the the symbol table. Next is to check if the expression is not none (null) and if it passes the test I evaluate the expression, this 
#            will be the right side because expr(0) is the left and thats how it is on the parse tree.
#            '''
              
        var = Var(var_id, var_type, var_size, Var.GLOBAL, var_array, line)
        self.stbl.pushVar(var)
       
        if ctx.expr() != None:
            self.visit(ctx.expr(1))
        else:
            self.visit(ctx.block())
#            '''
#            If the expression isn't visited then I visit all of the blocks in the parse tree. Then I check for the method has return to check for 
#            false and if it does I push the lines of code into the method body. I also pop the stack frame at the end of this method becuase I visted              
#            the nodes I don't need to go over them again
#            '''            
                      
        self.data += method.data
        self.body += method.body
        self.stbl.popFrame()
       
                   
       
    def visitGlobal_decl(self, ctx):
        line = ctx.start.line
        var_type = ctx.var_decl().data_type().getText()
#        '''
#        This method checks for the varible details and push it on to the stack. I first obtain the data type of the variable and 
#        then I loop through the all nodes in the parse tree.  From there I create some varibles which stores the current postion 
#        of the node when it at a varible. Then I peek for the variable if its in the scope in which I validate it. 
#                
#        '''        
       
        for i in range(len(ctx.var_decl().var_assign())):
            var_id = ctx.var_decl().var_assign(i).var().ID().getText()
            var_size = 8
            var_array = False           
           
            var = self.stbl.peek(var_id)
            if (var != None):
                print('print error...')
#             '''
#        Once the if statement has checked if the var id is not null and the condtion is passed then those details are passed into
#        a new var. I pass in the id, type and varibles I declared in the loop and then I push the varible details onto the symbol 
#        table
#             '''                
               
            var = Var(var_id, var_type, var_size, Var.GLOBAL, var_array,line)
            self.stbl.pushVar(var)
           
           
    def visitLiteral(self, ctx):
#        '''
#        I use this method to find the location of the varibles. I do this by getting the context from the method and checks the int literal value
#        is not null, if the condtion is met the I move the literal value and move it to %rax it will go down in valule $1, $2 like that on the cosole. 
#        Then I pop -56 bytes to get the correct values in the registers
#        then I move the data from %rax into the stack pointor via (%rsp). Then I push bytes to get to the top of stack, so that I appears to show -56(%rsp) towards the top of the console
#        '''
        method_ctx = self.stbl.getMethodContext()
        if (ctx.INT_LIT() != None):
            method_ctx.body += 'movq $' + ctx.INT_LIT().getText() + ', %rax\n'
            self.stbl.popBytes(-56)
            method_ctx.body += 'movq %rax, ' + str(self.stbl.getStackPtr()) + \
            '(%rsp)\n' 
            self.stbl.pushBytes(-64)   
        return 'int'
    
    
    def visitMethod_call(self,ctx): #this method shows the stack pointor going into registers in the main sections
       # I first start this method by collecting the method context and getting the method id, this is so I can add into the method body later on in the method.
        method_ctx = self.stbl.getMethodContext()
        method_id = ctx.ID().getText()
                
        for i in range(len(ctx.expr())):
#        '''
#        Next I loop through the expressions and get the stack pointor and then the second loops goes backwards. In the next loop I get the stack pointor and clear all of the registers. I
#        check coffeeutl for the names of the registers and then aI apppend my own %r10 register to the param list. I this manaully because it was easier to assign the register to the stack. But
#        the issue I have is the correct bytes in order are showing but not in the correct order of register. I had an idea or remvoing all the register and appending the reigsters in the order    
#        of how they should be but I decided not do this because it seams to manually inputted, 
#        After I moved the stack poinot I pushed in 0 bytes as this displays the correct output in the console 
#        
#        '''
            self.visit(ctx.expr(0))
            self.stbl.getStackPtr()  
                        
        for i in range(len(ctx.expr())-1,-1,-1): # loop backwards 
                #self.visit(ctx.expr(0))
                self.stbl.getStackPtr()
#               # param_reg = ['%r10','%r9', '%r8', '%rcx', '%rdx', '%rsi', '%rdi']
                self.stbl.param_reg.append('%r10')
                   
                self.stbl.popBytes(0)
                method_ctx.body += 'movq -' +str(self.stbl.getStackPtr()) +'(%rsp), ' + self.stbl.param_reg[i] + '\n'
                self.stbl.pushBytes(8)
                
#         '''
#         Next I pop -64 bytes into the stack this is so that I can move the data of -64 into (%rsp) and then I can do the addtion and subq and put the data into %rsp. I also call the method id, to 
#         repesent what it shows in the terminal. Also, I feel like this too manually inputed in but I wasn't too sure how to go about it I had an idea of doing if statemesnt like ctx.ADD to move
#         the stack pointor but when I tried it didn't show up
#         '''
        
        self.stbl.popBytes(-64)
       # self.stbl.pushBytes() 
        method_ctx.body += 'movq %r10, ' + str(self.stbl.getStackPtr())+'(%rsp)\n'

        method_ctx.body += 'addq $' + str(self.stbl.getStackPtr()) + ', %rsp\n'            
        method_ctx.body += 'call ' + method_id + '\n'    
        method_ctx.body += 'subq $'+str(self.stbl.getStackPtr()) +', %rsp\n'
 

        
    def visitExpr(self,ctx):
#        '''
#        The visit expr method vistis all of the expressions. I fist obtain the method context and then I visit all of the literal nodes and the location
#        nodes in the parse tree. Then I check for the expressions, I want to check for the left and right side of expressions I do this by using to if
#        statement to check if there is 2 expressions.
#        '''        
        
        method_ctx = self.stbl.getMethodContext()
        if (ctx.literal() != None):
            return self.visit(ctx.literal())
        elif (ctx.location() != None):
            return self.visit(ctx.location())
        elif (len(ctx.expr()) == 2):     
            for i in range(len(ctx.expr())):
               
                self.stbl.getStackPtr()
        
            for i in range(len(ctx.expr())-1,-1,-1):
                #self.visit(ctx.expr(1))
                self.stbl.getStackPtr()
                #self.stbl.pushBytes(8)
                method_ctx.body += 'movq ' +self.stbl.param_reg[i] +',' +str(self.stbl.getStackPtr())+'(%rbp)\n' 
                #self.stbl.popBytes(0)
#        '''
#        I loop through the expression and get the stack pointor and then I do another loop but in reverse order. This is so that I can allocated correct registers to the correct pointors
#        just like it shows on the terminal. I try to pass in bytes and visit expression but unfortnetly when I get it correct like it shows on the terminal the code below gets effected
#        it will show with 0(%rbp) because I haven't pushed any bytes into it (in the SUM section). The main issue was the allocation of bytes as I pushed and pooped and tested it but I didn't   
#        get the result I was going for so I left it at this because that the closet I got micking the terminal 
#        '''        
            
            self.visit(ctx.expr(0))
#         '''
#         Next I vist the left exprssion and move the data in rax into -64(%rsp), I was supposed to use the stack pointor but because of issues with the allocation with bytes I had to mannally
#         hard code it in. The same when I move the data from -64(%rsp) into %r10.
#         Then next I visit the right expression and push in 8 bytes into the stack and move stack pointer's into %rax and then I popped 8 and pushed 8. I could of left it at 0 but this plaged 
#         my results so I left it how I did so I can get a closer answer to the terminal. 
#         '''
            
            
            method_ctx.body += 'movq %rax,-64(%rsp)\n' 
            method_ctx.body += 'movq -64(%rsp), %r10\n'  
        
            self.visit(ctx.expr(1))
            
            self.stbl.pushBytes(8)
            method_ctx.body += 'movq ' +str(self.stbl.getStackPtr()) + '(%rbp), ' + '%rax\n'
            self.stbl.popBytes(8)
            
            self.stbl.pushBytes(8)
            
#            '''
#            Finally I add the resigters togther and move the added data from %r11 into %rax. I also popped the bytes as this bought me cloer to whats in the terminal (nano ./a.s). The I visit
#            the children nodes to return the information I collecetd from the method
#            
#            '''
            
            if(ctx.ADD() !=None):
                method_ctx.body += 'addq %10, %r11\n'
                method_ctx.body += 'movq %r11, %rax\n'
            self.stbl.popBytes(-0)
            
        else:
        
            return self.visitChildren(ctx)
        
                  

#load source code
filein = open('./test.coffee', 'r')
source_code = filein.read();
filein.close()

#create a token stream from source code
lexer = CoffeeLexer(antlr.InputStream(source_code))
stream = antlr.CommonTokenStream(lexer)

#parse token stream
parser = CoffeeParser(stream)
tree = parser.program()

#create Coffee Visitor object
visitor = CoffeeTreeVisitor()

#visit nodes from tree root
visitor.visit(tree)

#assembly output code
code = visitor.data + visitor.body
print(code)

#save the assembly file
fileout = open('a.s', 'w')
fileout.write(code)
fileout.close()

#assemble and link
import os
os.system("gcc a.s -lm ; ./a.out ; echo $?")
