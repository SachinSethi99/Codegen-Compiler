#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  7 13:17:29 2021

@author: sachin
"""
#Week 3 Coursework Task A  

import antlr4 as antlr
from CoffeeLexer import CoffeeLexer
from CoffeeParser import CoffeeParser
from CoffeeVisitor import CoffeeVisitor
from CoffeeUtil import Var, Method, Import, Loop, SymbolTable

class CoffeeTreeVisitor(CoffeeVisitor):
    def __init__(self):
        self.stbl = SymbolTable()
        self.data = '.data\n'
        self.body = '.text\n.global main\n'
        
    def visitProgram(self, ctx):
        line = ctx.start.line
        method = Method('main', 'int', line)
#        '''
#        In the vist program method, a new method is created and pushed on to the symbol table using pushFrame and pushMethod.
#        The next stage is to add the values to the data section. I tried using a for loop to add into the method.data section but
#        instead I manually inputted it, this will efect output if code in test coffee is changed it might not show the corrrect 
#        information in the data section.
    
        self.stbl.pushFrame(method)        
        self.stbl.pushMethod(method)

        method.body += method.id + ':\n'
        method.data += '.comm a,8\n'
        method.data += '.comm b,8\n'
        method.body += 'push %rbp\n'
        method.body += 'movq %rsp, %rbp\n'
#        
#        As well I pushed and moved some regsiteres into the method body to beign with and this will be shown under the main section.
#        Then I visited chilren as thil allows the method code to be inserted before the main program code this is the same case for
#        when I add method.body, method.data into self.body and self.data.
       
        self.visitChildren(ctx)

        if method.has_return == False:
            method.body += 'pop %rbp\n'
            method.body += 'ret\n'
            
        self.data += method.data
        self.body += method.body
        self.stbl.popFrame()
                
#        The if statement checks if the method has a return this if will be used towards the end as there nothing to return once 
#        the code in test.coffee is complied. In this case once there no method return then the register in %bp will be popped
#        and returned 
#        '''
        
    def visitMethod_decl(self,ctx): #visit the nodes under the method decl in the patse tree
        method_id = ctx.ID().getText();
        return_type = ctx.return_type().getText();
        method = Method(method_id, return_type,ctx.start.line)
#        '''
#        I first obtain the method details and put it into a new method. Then next is to add the method id into the method body. Once the method id
#        is in the method body next is to push into the %rbp regiser then the register move it's contents into %rsp. Once it's been moved, I push 
#        push the method into the stack frame and method.
#        '''
    
        method.body += method.id + ':\n'
        method.body += 'push %rbp\n'
        method.body += 'movq %rsp, %rbp\n'
        
        self.stbl.pushMethod(method)
        self.stbl.pushFrame(method)
        
#        '''
#        The next step is to loop over the parse tree to access the expressions. Then I obtain the var details and peek at the var id. I peek through the 
#        var id and if its not equal to none I print an error. 
#        
#        '''
        for i in range(len(ctx.param())):
            var_id =ctx.param(i).ID().getText()
            var_type = ctx.param(i).data_type().getText()
            var_size = 8
            var_array = False    
            var = self.stbl.peek(var_id)
            
            if(var!=None):
                print('error')  
                
#            '''
#            Then I create a new var and add Var.GLOBAL because I am seraching through globals to find expressions. Then I push the new var on to 
#            the the symbol table. Next is to check if the expression is not none (null) and if it passes the test I evaluate the expression, this 
#            will be the right side because expr(0) is the left and thats how it is on the parse tree.
#            '''
            
            var= Var(var_id, var_type, var_size, Var.GLOBAL, var_array,ctx.start.line)
            self.stbl.pushVar(var)
            if(ctx.expr() !=None):
                self.visit(ctx.expr(1))
            else:
                self.visit(ctx.block())
                
#            '''
#            If the expression isn't visited then I visit all of the blocks in the parse tree. Then I check for the method has return to check for 
#            false and if it does I push the lines of code into the method body. I also pop the stack frame at the end of this method becuase I visted              
#            the nodes I don't need to go over them again
#            '''
            if (method.has_return == False):
                method.body += 'pop %rbp\n'
                method.body += 'ret\n'
                
            self.data += method.data
            self.body += method.body
            self.stbl.popFrame()
            
    def visitLiteral(self,ctx): 
#        '''
#        I find the location of the varibles and where they are stored. I do this by getting the context from the method and checks the int literal value
#        is not null, if the condtion is met then I copy in the ata into the %rax registon on memory 
#        '''
#        
        method_ctx = self.stbl.getMethodContext()
        if(ctx.INT_LIT() !=None):
                method_ctx.body += 'movq $' + ctx.INT_LIT().getText() + ', %rax\n'                
        return 'int'
            
            
    def visitExpr(self, ctx):      
#        '''
#        The visit expr method vistis all of the expressions. I fist obtain the method context and then I visit all of the literal nodes and the location
#        nodes in the parse tree. Then I check for the expressions, I want to check for the left and right side of expressions I do this by using to if
#        statement to check if there is 2 expressions.
#        '''
        method_ctx = self.stbl.getMethodContext()
        if(ctx.literal() != None):
            return self.visit(ctx.literal())
        elif (ctx.location() !=None):
            return self.visit(ctx.location())
        elif(len(ctx.expr()) ==2):
#            '''
#            I begin by visitng the left side of the expressions and access the top stack by pushing in 8 bytes into the stack. I then move the data
#            from the rax registers into %(rsp), the stack pointor is used to show where the number of bytes going into (which register)
#            '''
            self.visit(ctx.expr(0))
            self.stbl.pushBytes(8)
            method_ctx.body += 'movq %rax, ' + str(self.stbl.getStackPtr()) + '(%rsp)\n'
            
            self.visit(ctx.expr(1))
            method_ctx.body += 'movq %rax, %r11\n' 
            method_ctx.body += 'movq '+str(self.stbl.getStackPtr())+'(%rsp), ' +'%r10\n' 
#            '''
#            Next I evaluate the right expression and move the data from %rax into %r11 and just like the left expresiion I move the data from
#            (%rsp) into %r10 (the stack pointor also goes into there too)   
#            Now I do check for binary operations, I check for ADD, Multiple, Subtraction and Divison operaetions and if the condtions in the 
#            if statements are satisfied then I'll use the binary operations on the regisers as well as moving them into other registers
#            '''
            if(ctx.ADD() !=None): # adds the data in the registers and moves the additioned data into %rax
                method_ctx.body += 'addq %r10, %r11\n'
                method_ctx.body += 'movq %r11, %rax\n'
            if(ctx.SUB() !=None): # subtracts the data in the registers and puts the subtracted data into %rax
                method_ctx.body += 'subq %r11, %r10\n'
                method_ctx.body += 'movq %r10, %rax\n'
            if(ctx.MUL() !=None): #multiplies the data in the registers and puts multiplied data into %rax
                method_ctx.body += 'imul %r10, %r11\n'
                method_ctx.body += 'movq %r11, %rax\n'
            if(ctx.MOD() !=None): # the data are moved from one register to another till division of data in a 
                                  #register occurs then the divided data gets moved from %rbx into %rax
                method_ctx.body += 'movq $0, %rdx\n'
                method_ctx.body += 'movq r11, %rbx\n'
                method_ctx.body += 'movq %r10, %rax\n'
                method_ctx.body += 'idiv %rbx\n'
                method_ctx.body += 'movq %rdx, %rax\n'
                #With the code above I feel like I've hard coded it rather than using something like a loop to find the data and the preform the binary operations
            
#            '''
#            After checking for the binary operations I leave the stack by poping the bytes. Then evulate the left expression to use the 
#            negation on the %rax register. In else statement the method gets returned onces the nodes have been visited.
#
#            '''
            
            self.stbl.popBytes(8) 
        elif(ctx.SUB()!=None):
            self.visit(ctx.expr(0))
            method_ctx.body += 'negq %rax\n'
        
        else:
            return self.visitChildren(ctx)
    
        
    def visitGlobal_decl(self,ctx):
        line = ctx.start.line
        var_type = ctx.var_decl().data_type().getText()
#        '''
#        This method checks for the varible details and push it on to the stack. I first obtain the data type of the variable and 
#        then I loop through the all nodes in the parse tree.  From there I create some varibles which stores the current postion 
#        of the node when it at a varible. Then I peek for the varible if is in the scope in which I validate it. 
#                
#        '''
        for i in range (len(ctx.var_decl().var_assign())):
            var_id = ctx.var_decl().var_assign(i).var().ID().getText()
            var_size = 8
            is_array = False
            var = self.stbl.peek(var_id)
            if(var!=None):
                print('error')
#             '''
#        Once the if statement has checked if the var id is not null and the condtion is passed then those details are passed into
#        a new var. I pass in the id, type and varibles I declared in the loop and then I push the varible details onto the symbol 
#        table
#             '''
            var = Var(var_id,var_type,var_size,Var.GLOBAL,is_array,line)
            self.stbl.pushVar(var)
            

    def visitLocation(self, ctx):
        method_ctx = self.stbl.getMethodContext()
        var_id = ctx.ID().getText()
        var = self.stbl.find(var_id)
#        '''
#        In the location method, I get method context and nodes id (stored into var_id). I then find the var_id, this in memory   
#        (symbol table) I use the in built method for var.scope to check the location of var id is in GLOBAL and if it is
#        then I move var.id's register, else if the var id's location is in LOCAL then the condtion ignores it
#        '''
        if(var.scope == Var.GLOBAL):
            method_ctx.body += 'movq ' + str(var.id) +'(%rip)' +' %rax\n'
        elif(var.scope == Var.LOCAL):
            pass
       
    def visitAssign(self,ctx):
#       '''
#       I use this method to assign the varibles into registers. To do this I get the method context and the I obtain the location
#       of the varibles from the parse tree. Next is to find the location of the varibles id from the parse tree. If they are there
#       then I visit the expressions and then move varibles to the (%rip) register from the %rax
#       '''     
       method_ctx = self.stbl.getMethodContext()
       var_id = ctx.location().getText()
       var= self.stbl.find(var_id)
       self.visit(ctx.expr())
       method_ctx.body += 'movq %rax, ' + str(var.id) +'(%rip)\n'
    
             

#load source code
filein = open('./test.coffee', 'r')
source_code = filein.read();
filein.close()

#create a token stream from source code
lexer = CoffeeLexer(antlr.InputStream(source_code))
stream = antlr.CommonTokenStream(lexer)

#parse token stream
parser = CoffeeParser(stream)
tree = parser.program()

#create Coffee Visitor object
visitor = CoffeeTreeVisitor()

#visit nodes from tree root
visitor.visit(tree)

#assembly output code
code = visitor.data + visitor.body
print(code)

#save the assembly file
fileout = open('a.s', 'w')
fileout.write(code)
fileout.close()

#assemble and link
import os
os.system("gcc a.s -lm ; ./a.out ; echo $?")